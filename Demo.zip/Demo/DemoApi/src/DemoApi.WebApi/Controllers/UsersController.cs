﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoApi.ApiServices.Services.UserServices;
using DemoApi.ApiViewModels.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DemoApi.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private IUserService userService;
        public UsersController(IUserService userService)
        {
            this.userService = userService;
        }

        [HttpGet("all")]
        [ProducesResponseType(typeof(List<UserViewModel>), 200)]
        public async Task<ActionResult<List<UserViewModel>>> GetAllUsers()
        {
            var result = await userService.GetAllUsers();
            return result;
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(UserViewModel), 200)]
        public async Task<ActionResult<UserViewModel>> GetUserById(int id)
        {
            var result = await userService.GetUserById(id);
            if (result != null)
                return result;
            else
                return NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(UserViewModel), 200)]
        public async Task<ActionResult<UserViewModel>> Post([FromBody] UserViewModel userViewModel)
        {
            if (ModelState.IsValid)
            {
                var result = await userService.SaveUser(userViewModel);
                if (result != null)
                    return result;
                else
                    return NotFound();
            }
            else
            {
                return BadRequest(userViewModel);
            }
        }

        [HttpPut]
        [ProducesResponseType(typeof(UserViewModel), 200)]
        public async Task<ActionResult<UserViewModel>> Put([FromBody] UserViewModel userViewModel)
        {
            if (ModelState.IsValid)
            {
                var result = await userService.UpdateUser(userViewModel);
                if (result != null)
                    return result;
                else
                    return NotFound();
            }
            else
            {
                return BadRequest(userViewModel);
            }
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(bool), 200)]
        public async Task<ActionResult<bool>> Delete(int id)
        {
            var result = await userService.DeleteUser(id);
            return result;
        }
    }
}
