﻿using AutoMapper;
using DemoApi.ApiData.Models;
using DemoApi.ApiViewModels.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoApi.ApiViewModels
{
    public class AutomapperConfiguration : Profile
    {
        public AutomapperConfiguration()
        {
            CreateMap<UserViewModel, User>(MemberList.None);
            CreateMap<User, UserViewModel>(MemberList.None);
        }
    }
}
