﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DemoApi.ApiData;
using DemoApi.ApiViewModels.ViewModels;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using DemoApi.ApiData.Models;

namespace DemoApi.ApiServices.Services.UserServices
{
    public class UserService : IUserService
    {
        private DemoDbContext dbContext;

        public UserService(DemoDbContext demoDbContext)
        {
            this.dbContext = demoDbContext;
        }

        public async Task<List<UserViewModel>> GetAllUsers()
        {
            var users = await this.dbContext.Users.ToListAsync();
            return Mapper.Map<List<UserViewModel>>(users);
        }

        public async Task<UserViewModel> GetUserById(int userId)
        {
            var user = await this.dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId);
            return Mapper.Map<UserViewModel>(user);
        }

        public async Task<UserViewModel> SaveUser(UserViewModel userData)
        {
            var mapper = Mapper.Map<User>(userData);
            this.dbContext.Users.Add(mapper);
            var count = await this.dbContext.SaveChangesAsync();
            if (count == 0)
                return null;
            else
                return Mapper.Map<UserViewModel>(mapper);
        }

        public async Task<UserViewModel> UpdateUser(UserViewModel userData)
        {
            var mapper = Mapper.Map<User>(userData);
            this.dbContext.Users.Update(mapper);
            var count = await this.dbContext.SaveChangesAsync();
            if (count == 0)
                return null;
            else
                return Mapper.Map<UserViewModel>(mapper);
        }

        public async Task<bool> DeleteUser(int userId)
        {
            var user = await this.dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId);
            this.dbContext.Users.Remove(user);
            var count = await this.dbContext.SaveChangesAsync();
            if (count == 0)
                return false;
            else
                return true;
        }
    }
}
