﻿using DemoApi.ApiViewModels.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoApi.ApiServices.Services.UserServices
{
    public interface IUserService
    {
        Task<List<UserViewModel>> GetAllUsers();

        Task<UserViewModel> GetUserById(int userId);

        Task<UserViewModel> SaveUser(UserViewModel userData);

        Task<UserViewModel> UpdateUser(UserViewModel userData);

        Task<bool> DeleteUser(int userId);
    }
}
