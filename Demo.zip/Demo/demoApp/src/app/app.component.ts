import { Component, OnInit } from '@angular/core';
import { UsersService } from './core/services';
import { UserViewModel } from './core/models';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'demoApp';
  public users:UserViewModel[];
  public currentUser:UserViewModel;

  constructor(private userService:UsersService){
    this.initUser();
  }

  ngOnInit(){
    this.initUsers();
  }

  initUsers(){
    this.userService.GetAllUsers().subscribe(
      result=>{
        this.users=result;
    });
  }

  initUser(){
    this.currentUser={
      age:0,
     id:0,
     name:'' 
    };
  }

  onSelect(user){
    this.currentUser=user;
  }

  saveUser(){
    if(this.currentUser.id<=0){
      this.userService.Post(this.currentUser).subscribe(
        result=>{
          if(result){
            this.initUsers();
          }
        }
      );
    } else {
      this.userService.Put(this.currentUser).subscribe(
        result=>{
          if(result){
            this.initUsers();
          }
        }
      );
    }
  }

  deleteUser(id){
    this.userService.Delete(id).subscribe(
      result=>{
        if(result){
          this.initUsers();
        }
      }
    );
  }
}
