/* tslint:disable */
import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpResponse, HttpHeaders } from '@angular/common/http';
import { BaseService as __BaseService } from '../base-service';
import { ApiConfiguration as __Configuration } from '../api-configuration';
import { StrictHttpResponse as __StrictHttpResponse } from '../strict-http-response';
import { Observable as __Observable } from 'rxjs';
import { map as __map, filter as __filter } from 'rxjs/operators';

import { UserViewModel } from '../models/user-view-model';
@Injectable({
  providedIn: 'root',
})
class UsersService extends __BaseService {
  static readonly GetAllUsersPath = '/api/Users/all';
  static readonly GetUserByIdPath = '/api/Users/{id}';
  static readonly DeletePath = '/api/Users/{id}';
  static readonly PutPath = '/api/Users';
  static readonly PostPath = '/api/Users';

  constructor(
    config: __Configuration,
    http: HttpClient
  ) {
    super(config, http);
  }

  /**
   * @return Success
   */
  GetAllUsersResponse(): __Observable<__StrictHttpResponse<Array<UserViewModel>>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/Users/all`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<Array<UserViewModel>>;
      })
    );
  }
  /**
   * @return Success
   */
  GetAllUsers(): __Observable<Array<UserViewModel>> {
    return this.GetAllUsersResponse().pipe(
      __map(_r => _r.body as Array<UserViewModel>)
    );
  }

  /**
   * @param id undefined
   * @return Success
   */
  GetUserByIdResponse(id: number): __Observable<__StrictHttpResponse<UserViewModel>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'GET',
      this.rootUrl + `/api/Users/${id}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<UserViewModel>;
      })
    );
  }
  /**
   * @param id undefined
   * @return Success
   */
  GetUserById(id: number): __Observable<UserViewModel> {
    return this.GetUserByIdResponse(id).pipe(
      __map(_r => _r.body as UserViewModel)
    );
  }

  /**
   * @param id undefined
   * @return Success
   */
  DeleteResponse(id: number): __Observable<__StrictHttpResponse<boolean>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;

    let req = new HttpRequest<any>(
      'DELETE',
      this.rootUrl + `/api/Users/${id}`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'text'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return (_r as HttpResponse<any>).clone({ body: (_r as HttpResponse<any>).body === 'true' }) as __StrictHttpResponse<boolean>
      })
    );
  }
  /**
   * @param id undefined
   * @return Success
   */
  Delete(id: number): __Observable<boolean> {
    return this.DeleteResponse(id).pipe(
      __map(_r => _r.body as boolean)
    );
  }

  /**
   * @param userViewModel undefined
   * @return Success
   */
  PutResponse(userViewModel?: UserViewModel): __Observable<__StrictHttpResponse<UserViewModel>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = userViewModel;
    let req = new HttpRequest<any>(
      'PUT',
      this.rootUrl + `/api/Users`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<UserViewModel>;
      })
    );
  }
  /**
   * @param userViewModel undefined
   * @return Success
   */
  Put(userViewModel?: UserViewModel): __Observable<UserViewModel> {
    return this.PutResponse(userViewModel).pipe(
      __map(_r => _r.body as UserViewModel)
    );
  }

  /**
   * @param userViewModel undefined
   * @return Success
   */
  PostResponse(userViewModel?: UserViewModel): __Observable<__StrictHttpResponse<UserViewModel>> {
    let __params = this.newParams();
    let __headers = new HttpHeaders();
    let __body: any = null;
    __body = userViewModel;
    let req = new HttpRequest<any>(
      'POST',
      this.rootUrl + `/api/Users`,
      __body,
      {
        headers: __headers,
        params: __params,
        responseType: 'json'
      });

    return this.http.request<any>(req).pipe(
      __filter(_r => _r instanceof HttpResponse),
      __map((_r) => {
        return _r as __StrictHttpResponse<UserViewModel>;
      })
    );
  }
  /**
   * @param userViewModel undefined
   * @return Success
   */
  Post(userViewModel?: UserViewModel): __Observable<UserViewModel> {
    return this.PostResponse(userViewModel).pipe(
      __map(_r => _r.body as UserViewModel)
    );
  }
}

module UsersService {
}

export { UsersService }
