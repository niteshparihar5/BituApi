/* tslint:disable */
export interface UserViewModel {
  id?: number;
  name?: string;
  age?: number;
}
